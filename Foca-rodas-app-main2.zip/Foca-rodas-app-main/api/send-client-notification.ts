import admin from "firebase-admin";

let adminApp: admin.app.App | null = null;
const getAdmin = () => {
  if (!adminApp) {
    const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
    const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
    const projectId = process.env.FIREBASE_PROJECT_ID;

    if (!privateKey || !clientEmail || !projectId) {
      throw new Error("Missing Firebase Admin credentials (FIREBASE_PRIVATE_KEY, FIREBASE_CLIENT_EMAIL, FIREBASE_PROJECT_ID)");
    }

    try {
      adminApp = admin.app(); // Use default app if already initialized
    } catch {
      adminApp = admin.initializeApp({
        credential: admin.credential.cert({
          projectId,
          clientEmail,
          privateKey,
        }),
      });
    }
  }
  return adminApp;
};

export default async function handler(req, res) {
  // CORS setup
  res.setHeader('Access-Control-Allow-Credentials', true)
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT')
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  )

  if (req.method === 'OPTIONS') {
    res.status(200).end()
    return
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { token, tokens, title, body } = req.body || {};
    
    // Support either a single token or an array of tokens
    const pushTokens = tokens || (token ? [token] : []);

    if (!pushTokens || pushTokens.length === 0) {
      return res.status(400).json({ error: "Token(s) is required" });
    }
    
    if (!title || !body) {
      return res.status(400).json({ error: "Title and body are required" });
    }

    console.log(`[Vercel Serverless] Sending real notification to ${pushTokens.length} token(s)...`);

    // Prepare message
    const messageBase = {
      notification: {
        title,
        body,
      },
      webpush: {
        headers: {
          "Urgency": "high"
        },
        notification: {
          requireInteraction: false,
        },
        fcmOptions: {
          link: "/",
        }
      }
    };
    
    let responses = [];
    
    // Send to each token
    for (const t of pushTokens) {
        const message = { ...messageBase, token: t };
        const response = await getAdmin().messaging().send(message);
        responses.push(response);
    }
    
    console.log("[Vercel Serverless] Successfully sent messages:", responses);
    
    return res.status(200).json({ success: true, messageIds: responses });
  } catch (error) {
    console.error("[Vercel Serverless] Error sending notification:", error);
    return res.status(500).json({ 
      error: "Failed to send notification", 
      details: error instanceof Error ? error.message : "Unknown error" 
    });
  }
}
