import admin from "firebase-admin";

let adminApp: admin.app.App | null = null;
const getAdmin = () => {
  if (!adminApp) {
    let privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
    let clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
    let projectId = process.env.FIREBASE_PROJECT_ID;

    if (!privateKey || !clientEmail || !projectId) {
        console.warn("[Backend] Using hardcoded credentials as fallback...");
        projectId = "foca-rodas";
        clientEmail = "firebase-adminsdk-fbsvc@foca-rodas.iam.gserviceaccount.com";
        privateKey = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCoXPsLSz68sqWO\nA1QVqSoUPwuqQKN47NkGpn0nmvUIMhnn4QRNbCE92uk50J3ImpuHOS8F7R9fNj3v\nHCeZtmg/H9shYqR78vRSuIJ2GGWvQU+vUJDbK0cE28FLsWCOVm+Lpd49E4vcY7kP\nxSwGnzabI2/Fu4auyMYe8185RjvNRuQpuAJUTR61dWXk9CDLxeimr3KcmvB16rUc\noK5arBtQd7WBgWhhQOXcoiSxQC+iPezeBLJMfHN8sn4Vynv5uIlKMyYLeZA1ba+3\nMHCLjjyF9N8/4u4/b5mf1wFpCISsNc3wB4ey4UL916uJsBhcjbUIZoqvmWuTMf+E\nZQU8vpclAgMBAAECggEADq2If1wQfJ/wefiFUJweXISAjlezSLwRUZibKaRDP3Mq\nugHuf5dxMHTQx2cOEmqUK45LMK+TABh4/ssMEsUJwpMS5g60+09biIioawZGeyhs\n+4JBFrJnrx8/c0tj+RTFBb4wqU92boDNJfhRFcS0nILS4ECwhbVgPFuITjR2yzcC\nPBZx1lXUImbQRo1uQq61WocfP7Gf/5RR31sGV/3Hra6iMhSIqsbieWj8Yl7z9Er/\nkCscR9guyzWJuAshSZyjbWX3+Z+eGxHtjKVANkNaNCxK6QxR9MY2yuLHjr9hKWQW\nBgIS6/v+xbZoXzfgQYPXD8zFUtU00p6n3tZtOZVJswKBgQDX8/syibehSjarl4Ks\nhiiiGoF+Y+SUpVYpSW6CQ+MVF0jmIWVvUvQVxe6ZiNKo9QWuOFonzpmZ1JhN9ujg\nigh3l0IrEPL2NhN3sRcY5ceBKkdpjj5umTAdh3rCIZufImd+/1+3O8iLVFCFMZsW\n5PsrVbiW8bAtkyuBenJJPT3evwKBgQDHlb/Fsom6ywVBgtfHBhpfbUOsLnUXAXjQ\nNrcO8R7A17zlV+CGw4nlETEk++Aab7P2AkXRqxjhWIL+KHoAIJX3wSwEpxH1+eJy\nVfPYk6B9xVpiqI8afsndlsFa1WWB94Zrs47WiKoOnyWxTgMP4IyHyZU8aayXD2UU\nHg2GkPcnGwKBgQDIRKpbJt5VxIZIwVxc9JmwI1adyLPNqjrqVQAX7C8mew6O5L+1\n6r8ThhiM6Bc8uuYGuJnbOry1rTOFcgprWXcauPqTB8fZzzJkmKVr4IQQ5A2P9Wsu\nk//MEr0kVZiFjplebCPuwJFtrMZzjxpdtAK+IGPsD70rtsTs8YoVI6dB7wKBgB7N\nC3V1IjBDmKINkUNTu8oyUJlH6iYMwhpP91xE9dwI70vtjeb+Uk+ZoZ31iRZLWtiC\nbUf4QbS1NjIHCRzv6nT7yNFG/0yYrcu7XBB2Z/RA+rvzC3KpUnnyBBECkdHG42XH\npimRmbz77pM4WNygaM+j2nYiUNJXO+Ao6ylzQdE1AoGAeRPCjAsnohA0PDSUBHYR\nkDP/XpszPhO14tTBQ6lNfrU51ZJMQOaC/NxTJpZINp5vqJr7rx5ntvTOOMYDvz6q\nCOefxQ3U7Br9KVIcD3djXMdwM9SphxNpwiaclVkrZz9sqrpvGdDUug2RSQL8HP1x\nGm/T4T2ziZh5t7FeN1ML4Tk=\n-----END PRIVATE KEY-----\n";
    }

    try {
      adminApp = admin.app(); // Use default app if already initialized
    } catch {
      adminApp = admin.initializeApp({
        credential: admin.credential.cert({
          projectId,
          clientEmail,
          privateKey,
        }),
      });
    }
  }
  return adminApp;
};

export default async function handler(req, res) {
  // CORS setup
  res.setHeader('Access-Control-Allow-Credentials', true)
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT')
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  )

  if (req.method === 'OPTIONS') {
    res.status(200).end()
    return
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { token } = req.body || {};

    if (!token) {
      return res.status(400).json({ error: "Token is required" });
    }

    console.log(`[Vercel Serverless] Sending test notification to token: ${token.substring(0, 10)}...`);

    const now = new Date();
    const timeString = now.toLocaleTimeString('pt-BR');
    const randomId = Math.floor(Math.random() * 10000);

    const message = {
      notification: {
        title: `Foca Rodas - Atualização de Veículo (Ref: #${randomId})`,
        body: `Olá! Os registros do sistema foram sincronizados às ${timeString}. Tudo operando normalmente.`,
      },
      webpush: {
        headers: {
          "Urgency": "high"
        },
        notification: {
          requireInteraction: false,
        },
        fcmOptions: {
          link: "/",
        }
      },
      token: token,
    };

    const response = await getAdmin().messaging().send(message);
    console.log("[Vercel Serverless] Successfully sent message:", response);
    
    return res.status(200).json({ success: true, messageId: response });
  } catch (error) {
    console.error("[Vercel Serverless] Error sending notification:", error);
    return res.status(500).json({ 
      error: "Failed to send notification", 
      details: error instanceof Error ? error.message : "Unknown error" 
    });
  }
}
