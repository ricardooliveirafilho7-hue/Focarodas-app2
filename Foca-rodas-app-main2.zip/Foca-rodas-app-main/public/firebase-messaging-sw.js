importScripts("https://www.gstatic.com/firebasejs/10.8.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.8.1/firebase-messaging-compat.js");

// We rely on URL query params injected during serviceWorker.register
const urlParams = new URLSearchParams(location.search);

const firebaseConfig = {
  apiKey: urlParams.get('apiKey') || "AIzaSyCc0LMofOWcym-VY-c3CEpttMHBL2SklC4",
  authDomain: urlParams.get('projectId') ? `${urlParams.get('projectId')}.firebaseapp.com` : "foca-rodas.firebaseapp.com",
  projectId: urlParams.get('projectId') || "foca-rodas",
  storageBucket: urlParams.get('projectId') ? `${urlParams.get('projectId')}.firebasestorage.app` : "foca-rodas.firebasestorage.app",
  messagingSenderId: urlParams.get('messagingSenderId') || "652557172003",
  appId: urlParams.get('appId') || "1:652557172003:web:bae1c71fb762a7d1efa096"
};

try {
  if (firebaseConfig.apiKey) {
    firebase.initializeApp(firebaseConfig);
    const messaging = firebase.messaging();

    // Let Firebase handle the background notifications natively since we are sending 'notification' payload
    // messaging.onBackgroundMessage(...) is not needed if we send standard notification payloads

  } else {
    console.warn("[firebase-messaging-sw.js] Configuração do Firebase não encontrada.");
  }
} catch (e) {
  console.error("Erro no Service Worker:", e);
}
