-- RUN THIS SCRIPT IN SUPABASE SQL EDITOR TO CREATE MISSING TABLES

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS public.clients (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  login TEXT,
  password TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  observations TEXT,
  status TEXT DEFAULT 'Ativo',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.employees (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  login TEXT,
  password TEXT,
  email TEXT,
  role TEXT,
  active BOOLEAN DEFAULT true,
  avatar TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.vehicles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  model TEXT NOT NULL,
  plate TEXT NOT NULL,
  year TEXT,
  color TEXT,
  mileage TEXT,
  photo TEXT,
  observations TEXT,
  brand TEXT,
  general_state TEXT,
  tires_state TEXT,
  wheels_state TEXT,
  damage TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.service_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  short_id TEXT,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  vehicle_id UUID REFERENCES public.vehicles(id) ON DELETE CASCADE,
  title TEXT,
  description TEXT,
  status TEXT NOT NULL,
  priority TEXT,
  services_full TEXT,
  observations TEXT,
  public_notes TEXT,
  internal_notes TEXT,
  technician_id UUID REFERENCES public.employees(id) ON DELETE SET NULL,
  delivery_estimate TEXT,
  finished_at TIMESTAMP WITH TIME ZONE,
  updates JSONB DEFAULT '[]'::jsonb,
  photos JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  sender_id TEXT,
  sender_role TEXT,
  title TEXT,
  content TEXT,
  type TEXT,
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Turn off RLS temporarily for easy testing, or keep it on and allow public
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public access on clients" ON public.clients FOR ALL USING (true);
CREATE POLICY "Allow public access on employees" ON public.employees FOR ALL USING (true);
CREATE POLICY "Allow public access on vehicles" ON public.vehicles FOR ALL USING (true);
CREATE POLICY "Allow public access on service_orders" ON public.service_orders FOR ALL USING (true);
CREATE POLICY "Allow public access on messages" ON public.messages FOR ALL USING (true);
