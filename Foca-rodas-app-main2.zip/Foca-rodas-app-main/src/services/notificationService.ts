import { requestFCMToken } from "../lib/firebase";

/**
 * Interface para os logs de status do processo
 */
export interface NotificationLog {
  step: string;
  status: 'pending' | 'success' | 'error';
  message: string;
}

/**
 * Verifica se o navegador suporta notificações e service workers
 */
export const checkNotificationSupport = (): { ok: boolean; reason?: string } => {
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || ('standalone' in navigator && (navigator as any).standalone);

  if (isIOS && !isStandalone) {
    return { ok: false, reason: "No iPhone/iPad (iOS), você precisa adicionar este site à 'Tela de Início' primeiro para receber notificações." };
  }

  if (!('serviceWorker' in navigator)) {
    return { ok: false, reason: "Service Workers não são suportados neste navegador." };
  }
  
  if (!('Notification' in window)) {
    return { ok: false, reason: "Navegador não suporta notificações Push." };
  }
  
  return { ok: true };
};

/**
 * Envia uma notificação de teste disparando o endpoint do backend
 * @param token Token FCM do dispositivo
 */
export const sendBackendTestNotification = async (token: string): Promise<{ success: boolean; error?: string }> => {
  try {
    console.log("[NotificationService] Solicitando envio de notificação de teste ao backend...");
    
    const response = await fetch("/api/send-test-notification", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ token }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.details || data.error || "Falha ao enviar notificação");
    }

    console.log("[NotificationService] Notificação enviada com sucesso:", data);
    return { success: true };
  } catch (error) {
    console.error("[NotificationService] Erro no envio:", error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Erro desconhecido no servidor" 
    };
  }
};

/**
 * Fluxo principal do botão de teste
 * @param onLog Callback para atualizar a UI com o progresso
 */
export const handleTestNotificationFlow = async (
  onLog: (log: NotificationLog) => void
) => {
  onLog({ step: 'support', status: 'pending', message: 'Verificando suporte do navegador...' });

  // 1. Verificar suporte
  const support = checkNotificationSupport();
  if (!support.ok) {
    onLog({ step: 'support', status: 'error', message: support.reason || 'Navegador não suporta notificações.' });
    return;
  }
  onLog({ step: 'support', status: 'success', message: 'Navegador compatível e pronto!' });

  // 2. Pedir permissão explicitamente via API nativa do navegador
  onLog({ step: 'permission', status: 'pending', message: 'Solicitando permissão de notificação ao usuário...' });
  
  let permission = window.Notification.permission;
  if (permission !== 'granted') {
    const permissionResult = window.Notification.requestPermission();
    if (permissionResult instanceof Promise) {
      permission = await permissionResult;
    } else {
      permission = await new Promise((resolve) => {
        window.Notification.requestPermission((res) => {
          resolve(res);
        });
      });
    }
  }
  
  if (permission !== 'granted') {
    onLog({ step: 'permission', status: 'error', message: 'Permissão negada. É necessário autorizar os alertas nas configurações do site.' });
    return;
  }
  onLog({ step: 'permission', status: 'success', message: 'Permissão concedida pelo usuário!' });

  // 3. Obter o Token do Firebase
  onLog({ step: 'token', status: 'pending', message: 'Obtendo token de registro (FCM)...' });
  
  try {
    let token = null;
    try {
      token = await requestFCMToken();
    } catch (err) {
      onLog({ step: 'token', status: 'error', message: `Erro do FCM: ${err instanceof Error ? err.message : String(err)}` });
      return;
    }

    if (!token) {
      onLog({ step: 'token', status: 'error', message: 'Falha ao obter token de notificação Push: Nenhum token retornado pelo FCM.' });
      return;
    }

    onLog({ step: 'token', status: 'success', message: 'Token obtido (pronto para envio).' });
    console.log("[FCM Token]:", token);

    // 4. Enviar notificação automática
    onLog({ step: 'send', status: 'pending', message: 'Disparando notificação de teste para este dispositivo...' });
    
    const result = await sendBackendTestNotification(token);

    if (result.success) {
      onLog({ step: 'send', status: 'success', message: 'Notificação enviada! Verifique seu dispositivo.' });
    } else {
      onLog({ step: 'send', status: 'error', message: `Erro ao enviar: ${result.error}` });
    }

  } catch (error) {
    onLog({ step: 'token', status: 'error', message: `Erro inesperado: ${error instanceof Error ? error.message : 'Falha crítica'}` });
  }
};
