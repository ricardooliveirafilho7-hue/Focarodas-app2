import { NavLink, Outlet } from 'react-router-dom';
import { Home, PlusCircle } from 'lucide-react';

export function Layout() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <header className="bg-slate-900 border-b-8 border-slate-900 sticky top-0 z-10 pt-4 pb-2">
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-black text-white uppercase tracking-tighter leading-none">Foca Rodas</h1>
            <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase mt-1 leading-none">Centro Automotivo</p>
          </div>
          <nav className="flex space-x-2">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `p-2 px-3 rounded-xl flex flex-col items-center justify-center transition-colors ${
                  isActive ? 'text-blue-500' : 'text-slate-400 hover:text-white'
                }`
              }
            >
              <Home size={18} />
              <span className="text-[8px] mt-1 font-bold uppercase tracking-tighter">Home</span>
            </NavLink>
            <NavLink
              to="/register"
              className={({ isActive }) =>
                `p-2 px-3 rounded-xl flex flex-col items-center justify-center transition-colors ${
                  isActive ? 'text-blue-500' : 'text-slate-400 hover:text-white'
                }`
              }
            >
              <PlusCircle size={18} />
              <span className="text-[8px] mt-1 font-bold uppercase tracking-tighter">Novo</span>
            </NavLink>
          </nav>
        </div>
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <Outlet />
      </main>
    </div>
  );
}
