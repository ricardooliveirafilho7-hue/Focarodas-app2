import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from './supabase';
import { Vehicle, ServiceOrder, Client, UserRole, ServiceStatus, ServiceUpdate, Employee, AuditLog, Settings, Message } from '../types';

const toCamel = (obj: any): any => {
  if (Array.isArray(obj)) return obj.map(v => toCamel(v));
  if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj).reduce((result, key) => {
      const camelKey = key.replace(/([-_][a-z])/ig, ($1) => $1.toUpperCase().replace('-', '').replace('_', ''));
      result[camelKey] = toCamel(obj[key]);
      return result;
    }, {} as any);
  }
  return obj;
};

const toSnake = (obj: any): any => {
  if (Array.isArray(obj)) return obj.map(v => toSnake(v));
  if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj).reduce((result, key) => {
      const snakeKey = key.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
      result[snakeKey] = toSnake(obj[key]);
      return result;
    }, {} as any);
  }
  return obj;
};

interface AppState {
  vehicles: Vehicle[];
  serviceOrders: ServiceOrder[];
  clients: Client[];
  employees: Employee[];
  logs: AuditLog[];
  messages: Message[];
  settings: Settings;
  role: UserRole;
  currentUser: Client | Employee | { id: string, name: string } | null;
  activeVehicleId: string | null;
}

interface AppContextType extends AppState {
  setRole: (role: UserRole) => void;
  setCurrentUser: (user: any) => void;
  loginUser: (login: string, pass: string, panel: 'cliente' | 'funcionario' | 'admin') => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  addVehicleUpdate: (
    serviceOrderId: string, 
    status: ServiceStatus, 
    publicMessage: string, 
    internalNote: string, 
    photos: string[], 
    deliveryEstimate: string,
    notifyClient: boolean
  ) => Promise<void>;
  setActiveVehicleId: (id: string | null) => void;
  getVehicleById: (id: string) => Vehicle | undefined;
  getServiceOrderById: (id: string) => ServiceOrder | undefined;
  getClientById: (id: string) => Client | undefined;
  addLog: (action: string, target: string, type: 'edit' | 'add' | 'alert' | 'delete' | 'info', details?: string, targetId?: string) => void;
  createClient: (client: Omit<Client, 'id'>) => Promise<{ success: boolean; error?: string; client?: Client }>;
  updateClient: (id: string, client: Partial<Client>) => Promise<boolean>;
  createVehicle: (vehicle: Omit<Vehicle, 'id'>) => Promise<Vehicle | null>;
  updateVehicle: (id: string, vehicle: Partial<Vehicle>) => Promise<boolean>;
  createServiceOrder: (order: Omit<ServiceOrder, 'id' | 'updates'>) => Promise<ServiceOrder | null>;
  updateServiceOrder: (id: string, order: Partial<ServiceOrder>) => Promise<boolean>;
  createEmployee: (employee: Omit<Employee, 'id'>) => Promise<{ success: boolean; error?: string; employee?: Employee }>;
  updateEmployee: (id: string, employee: Partial<Employee>) => Promise<boolean>;
  sendMessage: (msg: Omit<Message, 'id' | 'createdAt' | 'read'>) => Promise<boolean>;
  markMessageAsRead: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [serviceOrders, setServiceOrders] = useState<ServiceOrder[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [settings, setSettings] = useState<Settings>({ darkMode: true });
  
  const [role, setRole] = useState<UserRole>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [activeVehicleId, setActiveVehicleId] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);

  // Load session
  useEffect(() => {
    const savedRole = localStorage.getItem('foca_role_v3') as UserRole;
    const savedUser = localStorage.getItem('foca_user_v3');
    if (savedRole && savedUser) {
      setRole(savedRole);
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  // Fetch data from Supabase
  useEffect(() => {
    async function loadData() {
      if (!role || !currentUser) {
        setIsReady(true);
        return;
      }
      
      try {
        // We load everything for ADMIN / STAFF, but restricted for CLIENT
        if (role === 'CLIENT') {
          const [resClients, resVehicles, resOrders, resMsgs] = await Promise.all([
             supabase.from('clients').select('*').eq('id', currentUser.id),
             supabase.from('vehicles').select('*').eq('client_id', currentUser.id),
             supabase.from('service_orders').select('*').eq('client_id', currentUser.id),
             supabase.from('messages').select('*').eq('client_id', currentUser.id).order('created_at', { ascending: false })
          ]);
          if (resClients.data) setClients(toCamel(resClients.data));
          if (resVehicles.data) setVehicles(toCamel(resVehicles.data));
          if (resOrders.data) setServiceOrders(toCamel(resOrders.data));
          if (resMsgs.data) setMessages(toCamel(resMsgs.data));
        } else {
          const [resClients, resVehicles, resOrders, resEmps, resMsgs] = await Promise.all([
             supabase.from('clients').select('*'),
             supabase.from('vehicles').select('*'),
             supabase.from('service_orders').select('*').order('created_at', { ascending: false }),
             supabase.from('employees').select('*'),
             supabase.from('messages').select('*').order('created_at', { ascending: false })
          ]);
          if (resClients.data) setClients(toCamel(resClients.data));
          if (resVehicles.data) setVehicles(toCamel(resVehicles.data));
          if (resOrders.data) setServiceOrders(toCamel(resOrders.data));
          if (resEmps.data) {
             let loadedEmps = toCamel(resEmps.data);
             // Ensure admin exists
             if (!loadedEmps.find((e: any) => e.id === 'admin1')) {
                loadedEmps.push({ id: 'admin1', name: 'Administrador', login: 'admin', password: '123456', email: 'admin@focarodas.com', role: 'Administrador', active: true });
             }
             setEmployees(loadedEmps);
          }
          if (resMsgs.data) setMessages(toCamel(resMsgs.data));
        }
      } catch (err) {
        console.error("Supabase load error", err);
      }
      
      setIsReady(true);
    }
    loadData();
    
    // Setup Supabase Realtime listeners
    if (role && currentUser) {
      const channel = supabase.channel('schema-db-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, payload => {
           // Basic update
           if (payload.eventType === 'INSERT') {
             setMessages(prev => [toCamel(payload.new) as Message, ...prev]);
           } else if (payload.eventType === 'UPDATE') {
             setMessages(prev => prev.map(m => m.id === payload.new.id ? (toCamel(payload.new) as Message) : m));
           }
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'service_orders' }, payload => {
           if (payload.eventType === 'INSERT') {
             setServiceOrders(prev => [toCamel(payload.new) as ServiceOrder, ...prev]);
           } else if (payload.eventType === 'UPDATE') {
             setServiceOrders(prev => prev.map(o => o.id === payload.new.id ? (toCamel(payload.new) as ServiceOrder) : o));
           }
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'vehicles' }, payload => {
           if (payload.eventType === 'INSERT') {
             setVehicles(prev => [toCamel(payload.new) as Vehicle, ...prev]);
           } else if (payload.eventType === 'UPDATE') {
             setVehicles(prev => prev.map(o => o.id === payload.new.id ? (toCamel(payload.new) as Vehicle) : o));
           }
        })
        .subscribe();
        
      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [role, currentUser?.id]);

  useEffect(() => {
    if (role !== null) localStorage.setItem('foca_role_v3', role);
    else localStorage.removeItem('foca_role_v3');
    
    if (currentUser !== null) localStorage.setItem('foca_user_v3', JSON.stringify(currentUser));
    else localStorage.removeItem('foca_user_v3');
  }, [role, currentUser]);

  const addLog = (action: string, target: string, type: 'edit' | 'add' | 'alert' | 'delete' | 'info', details?: string, targetId?: string) => {
    const newLog: AuditLog = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser?.id || 'system',
      userName: currentUser?.name || 'Sistema',
      action,
      target,
      type,
      details,
      targetId,
      createdAt: new Date().toISOString()
    };
    setLogs(prev => [newLog, ...prev]);
  };

  const loginUser = async (loginUserStr: string, pass: string, panel: 'cliente' | 'funcionario' | 'admin') => {
    const inputLogin = (loginUserStr || '').trim();
    const inputPass = pass || '';

    if (!inputLogin || !inputPass) return { success: false, error: 'Login ou senha inválidos.' };

    try {
      // 1. Admin hardcoded test bypass
      if (panel === 'admin') {
        const testLogin = inputLogin.toLowerCase().replace(/\s+/g, '');
        const testPass = inputPass.toLowerCase().replace(/\s+/g, '');
        if ((testLogin === 'admin' || testLogin === 'focarodas') && (testPass === '123456' || testPass === 'focarodas' || testPass === 'admin')) {
           const adminC = { id: 'admin1', name: 'Administrador', login: 'admin', password: '123456', email: 'admin@focarodas.com', role: 'Administrador', active: true };
           setCurrentUser(adminC);
           setRole('ADMIN');
           return { success: true };
        }
      }

      // 2. Local test password bypass (as requested "senha: focarodas funcione para teste")
      const isBypass = inputPass === 'focarodas' || (panel === 'admin' && inputPass === '123456');

      let authUserId: string | null = null;

      if (!isBypass) {
        // Real Supabase Auth login
        const safeLogin = inputLogin.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        const loginEmail = inputLogin.includes('@') ? inputLogin : `${safeLogin}@focarodas.com`;
        const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
          email: loginEmail,
          password: inputPass
        });
        
        if (authError || !authData.user) {
          return { success: false, error: 'Login ou senha inválidos.' };
        }
        authUserId = authData.user.id;
      }

      // 3. Fetch specific role table
      if (panel === 'cliente') {
        let query = supabase.from('clients').select('*');
        if (authUserId) {
          query = query.eq('id', authUserId);
        } else {
          query = query.eq('login', inputLogin);
        }

        const { data, error } = await query.single();
        if (error || !data) return { success: false, error: 'Usuário não encontrado.' };
        
        const mappedData = toCamel(data);
        if (mappedData.status === 'Inativo') return { success: false, error: 'Conta inativa.' };
        
        setCurrentUser(mappedData);
        setRole('CLIENT');
        return { success: true };
      } 
      
      if (panel === 'funcionario' || panel === 'admin') {
        let query = supabase.from('employees').select('*');
        if (authUserId) {
          query = query.eq('id', authUserId);
        } else {
          query = query.eq('login', inputLogin);
        }
        
        const { data, error } = await query.single();
        if (error || !data) return { success: false, error: 'Usuário não encontrado.' };
        const mappedData = toCamel(data);
        if (!mappedData.active) return { success: false, error: 'Conta inativa.' };
        
        if (panel === 'admin') {
          if (mappedData.role === 'Administrador' || mappedData.role === 'Gerente') {
            setCurrentUser(mappedData);
            setRole('ADMIN');
            return { success: true };
          }
          return { success: false, error: 'Acesso negado ao painel administrador.' };
        } else {
          setCurrentUser(mappedData);
          setRole('STAFF');
          return { success: true };
        }
      }
    } catch(e) {
      console.error(e);
      return { success: false, error: 'Erro de conexão.' };
    }

    return { success: false, error: 'Login ou senha inválidos.' };
  };

  const logout = () => {
    setRole(null);
    setCurrentUser(null);
    setActiveVehicleId(null);
    setVehicles([]);
    setServiceOrders([]);
    setClients([]);
    setMessages([]);
  };

  const addVehicleUpdate = async (
    serviceOrderId: string, 
    status: ServiceStatus, 
    publicMessage: string, 
    internalNote: string, 
    photos: string[],
    deliveryEstimate: string,
    notifyClient: boolean
  ) => {
    const update: ServiceUpdate = {
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString(),
      status,
      publicMessage,
      internalNote,
      photos
    };

    const os = serviceOrders.find(o => o.id === serviceOrderId);
    if (!os) return;
    
    const updatedOs = {
      ...os,
      status,
      deliveryEstimate: deliveryEstimate || os.deliveryEstimate,
      updates: [update, ...os.updates]
    };
    
    const { error } = await supabase.from('service_orders').update(toSnake(updatedOs)).eq('id', serviceOrderId);
    if (error) {
       console.error("Error updating order", error);
       alert("Erro ao salvar o status no Supabase.");
       return;
    }

    setServiceOrders(prev => prev.map(o => o.id === serviceOrderId ? updatedOs : o));
    addLog('alterou o status da OS', `OS #${os.id} -> ${status}`, 'edit', internalNote, os.id);
    
    if (notifyClient) {
       await sendMessage({
          clientId: updatedOs.clientId,
          senderId: currentUser?.id || 'system',
          senderRole: role || 'STAFF',
          title: `Atualização de OS: ${status}`,
          content: publicMessage || `O status do seu veículo mudou para ${status}.`,
          type: 'info'
       });
    }
  };

  const getVehicleById = (id: string) => vehicles.find(v => v.id === id);
  const getServiceOrderById = (id: string) => serviceOrders.find(v => v.id === id);
  const getClientById = (id: string) => clients.find(c => c.id === id);

  const createClient = async (client: Omit<Client, 'id'>) => {
    try {
      const response = await fetch('/api/admin/create-client', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(client)
      });
      const data = await response.json();
      
      if (!response.ok || !data.success) {
        console.error("Erro Backend:", data.error);
        return { success: false, error: data.error || "Erro desconhecido" };
      }
      
      const newClientObj = toCamel(data.client) as Client;
      setClients(prev => [...prev, newClientObj]);
      addLog('criou novo cliente', client.name, 'add', '', newClientObj.id);
      return { success: true, client: newClientObj };
    } catch (e: any) {
      console.error(e);
      return { success: false, error: "Erro de conexão ao salvar cliente." };
    }
  };

  const updateClient = async (id: string, updates: Partial<Client>) => {
    try {
      const response = await fetch('/api/admin/update-client', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, updates: toSnake(updates) })
      });
      const data = await response.json();
      
      if (!response.ok || !data.success) {
        console.error("Erro Backend:", data.error);
        alert("Erro ao atualizar cliente: " + (data.error || "Erro desconhecido"));
        return false;
      }
      
      setClients(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
      return true;
    } catch (e: any) {
      console.error(e);
      alert("Erro de conexão ao atualizar cliente.");
      return false;
    }
  };

  const createVehicle = async (vehicle: Omit<Vehicle, 'id'>) => {
    const newVehicleObj = { ...vehicle, id: crypto.randomUUID(), createdAt: new Date().toISOString() };
    const { error } = await supabase.from('vehicles').insert([toSnake(newVehicleObj)]);
    if (error) {
       console.error("Supabase Error", error);
       if (error.message && error.message.includes("Could not find the table")) {
          alert("ERRO CRÍTICO: A tabela 'vehicles' não existe no Supabase. Por favor, execute o script do arquivo 'supabase-schema-v2.sql' no seu Supabase SQL Editor para criar as tabelas.");
       } else {
          alert("Não foi possível salvar o veículo. Erro: " + error.message);
       }
       return null;
    }
    setVehicles(prev => [...prev, newVehicleObj]);
    addLog('cadastrou um veículo', `${vehicle.model} (${vehicle.plate})`, 'add', '', newVehicleObj.id);
    return newVehicleObj;
  };

  const updateVehicle = async (id: string, updates: Partial<Vehicle>) => {
    const { error } = await supabase.from('vehicles').update(toSnake(updates)).eq('id', id);
    if (error) return false;
    setVehicles(prev => prev.map(v => v.id === id ? { ...v, ...updates } : v));
    return true;
  };

  const createServiceOrder = async (os: Omit<ServiceOrder, 'id' | 'updates'>) => {
    const newOSObj: ServiceOrder = { ...os, id: crypto.randomUUID(), updates: [], createdAt: new Date().toISOString() };
    const { error } = await supabase.from('service_orders').insert([toSnake(newOSObj)]);
    if (error) {
       console.error("Supabase Error", error);
       if (error.message && error.message.includes("Could not find the table")) {
          alert("ERRO CRÍTICO: A tabela 'service_orders' não existe no Supabase. Por favor, execute o script do arquivo 'supabase-schema-v2.sql' no seu Supabase SQL Editor para criar as tabelas.");
       } else {
          alert("Erro ao criar a Ordem de Serviço: " + error.message);
       }
       return null;
    }
    setServiceOrders(prev => [...prev, newOSObj]);
    alert("Ordem criada com sucesso.");
    return newOSObj;
  };

  const updateServiceOrder = async (id: string, updates: Partial<ServiceOrder>) => {
    const { error } = await supabase.from('service_orders').update(toSnake(updates)).eq('id', id);
    if (error) return false;
    setServiceOrders(prev => prev.map(v => v.id === id ? { ...v, ...updates } : v));
    return true;
  };

  const createEmployee = async (emp: Omit<Employee, 'id'>) => {
    try {
      const response = await fetch('/api/admin/create-employee', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(emp)
      });
      const data = await response.json();
      
      if (!response.ok || !data.success) {
        return { success: false, error: data.error || "Erro ao criar funcionário." };
      }
      
      const newEmployee = toCamel(data.employee) as Employee;
      setEmployees(prev => [...prev, newEmployee]);
      return { success: true, employee: newEmployee };
    } catch (e: any) {
      console.error(e);
      return { success: false, error: "Erro inesperado de conexão com o servidor." };
    }
  };

  const updateEmployee = async (id: string, updates: Partial<Employee>) => {
    try {
      const response = await fetch('/api/admin/update-employee', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, updates: toSnake(updates) })
      });
      const data = await response.json();
      
      if (!response.ok || !data.success) {
        console.error("Erro Backend:", data.error);
        alert("Erro ao atualizar funcionário: " + (data.error || "Erro desconhecido"));
        return false;
      }
      
      setEmployees(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
      return true;
    } catch (e: any) {
      console.error(e);
      alert("Erro de conexão ao atualizar funcionário.");
      return false;
    }
  };
  
  const sendMessage = async (msg: Omit<Message, 'id' | 'createdAt' | 'read'>) => {
     const newMsg = { ...msg, id: crypto.randomUUID(), createdAt: new Date().toISOString(), read: false };
     const { error } = await supabase.from('messages').insert([toSnake(newMsg)]);
     if (error) {
        alert("Erro ao enviar mensagem.");
        return false;
     }
     setMessages(prev => [newMsg, ...prev]);
     alert("Mensagem enviada com sucesso.");
     return true;
  };
  
  const markMessageAsRead = async (id: string) => {
     const { error } = await supabase.from('messages').update(toSnake({ read: true })).eq('id', id);
     if (error) return;
     setMessages(prev => prev.map(m => m.id === id ? { ...m, read: true } : m));
  };

  if (!isReady) {
    return <div className="app-container flex items-center justify-center text-white"><div className="w-8 h-8 border-4 border-[#E53935] border-t-transparent rounded-full animate-spin"></div></div>;
  }

  return (
    <AppContext.Provider value={{
      vehicles, serviceOrders, clients, employees, logs, settings, role, currentUser, activeVehicleId, messages,
      setRole, setCurrentUser, loginUser, logout,
      addVehicleUpdate, setActiveVehicleId, getVehicleById, getServiceOrderById, getClientById,
      addLog, createClient, updateClient, createVehicle, updateVehicle, createServiceOrder, updateServiceOrder, createEmployee, updateEmployee,
      sendMessage, markMessageAsRead
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useAppStore = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppStore must be used within an AppProvider');
  return context;
};
