import { initializeApp } from 'firebase/app';
import { getMessaging, getToken, onMessage } from 'firebase/messaging';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyCc0LMofOWcym-VY-c3CEpttMHBL2SklC4",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "foca-rodas.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "foca-rodas",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "foca-rodas.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "652557172003",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:652557172003:web:bae1c71fb762a7d1efa096",
};

let messaging: ReturnType<typeof getMessaging> | null = null;
let app: ReturnType<typeof initializeApp> | null = null;

try {
  if (firebaseConfig.apiKey) {
    app = initializeApp(firebaseConfig);
    messaging = getMessaging(app);
  }
} catch (error) {
  console.error("Firebase init error:", error);
}

export const requestFCMToken = async () => {
  const missingKeys = Object.entries(firebaseConfig)
    .filter(([_, v]) => !v)
    .map(([k]) => `VITE_FIREBASE_${k.toUpperCase().replace('APPID', 'APP_ID')}`);
  
  if (missingKeys.length > 0) {
    throw new Error(`Firebase VITE_ variables are missing: ${missingKeys.join(', ')}. Check your Secrets.`);
  }

  if (!messaging) {
    throw new Error('Firebase messaging module could not be initialized.');
  }
  
  const { apiKey, projectId, messagingSenderId, appId } = firebaseConfig;
  const swUrl = `/firebase-messaging-sw.js?apiKey=${apiKey}&projectId=${projectId}&messagingSenderId=${messagingSenderId}&appId=${appId}`;
  
  let registration;
  try {
    registration = await navigator.serviceWorker.register(swUrl);
    console.log('Service Worker registered successfully');
  } catch (err) {
    throw new Error(`SW Registration failed: ${err instanceof Error ? err.message : String(err)}`);
  }

  let status = Notification.permission;
  if (status !== 'granted') {
    const permissionResult = Notification.requestPermission();
    if (permissionResult instanceof Promise) {
      status = await permissionResult;
    } else {
      // Handle older Safari which uses callbacks
      status = await new Promise((resolve) => {
        Notification.requestPermission((res) => {
          resolve(res);
        });
      });
    }
  }

  if (status === 'granted') {
    const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY;
    
    try {
      const options: any = { serviceWorkerRegistration: registration };
      if (vapidKey) {
        options.vapidKey = vapidKey;
      }
      
      const currentToken = await getToken(messaging, options);
      if (currentToken) {
        return currentToken;
      } else {
        throw new Error('No registration token available.');
      }
    } catch (err) {
      throw new Error(`getToken failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  } else {
    throw new Error('Notification permission not granted.');
  }
}

export const setupFCMListener = (onMessageReceived?: (payload: any) => void) => {
  if (!messaging) return;
  onMessage(messaging, (payload) => {
    
    // Manually trigger a native notification if the app is in the foreground
    if (Notification.permission === 'granted') {
      const title = payload.notification?.title || payload.data?.title || 'Foca Rodas';
      const options = {
        body: payload.notification?.body || payload.data?.body || 'Você tem uma nova mensagem.',
        icon: '/favicon.ico',
        requireInteraction: false
      };
      
      navigator.serviceWorker.ready.then((registration) => {
        return registration.showNotification(title, options);
      }).catch((e) => {
        console.warn("SW showNotification failed, trying native Notification API", e);
        try {
          const n = new Notification(title, options);
          n.onclick = () => { window.focus(); n.close(); };
        } catch(err) {
          console.error("Native notification fallback also failed", err);
        }
      });
    }

    if (onMessageReceived) {
      onMessageReceived(payload);
    }
  });
}
