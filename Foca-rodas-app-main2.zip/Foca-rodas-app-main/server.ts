import "dotenv/config";
import express from "express";
import { createServer as createViteServer } from "vite";
import cors from "cors";
import path from "path";
import { createClient } from "@supabase/supabase-js";

// Initialize Supabase Admin Client
let supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || "";
supabaseUrl = supabaseUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/$/, '');
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_SERVICE_ROLE_KEY || "";

const supabaseAdmin = createClient(supabaseUrl || 'https://placeholder.supabase.co', supabaseServiceKey || 'placeholder', {
  auth: { autoRefreshToken: false, persistSession: false }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // === ADMIN API ROUTES ===

  // Create Employee
  app.post("/api/admin/create-employee", async (req, res) => {
    try {
      const { email, password, name, role, login, active } = req.body;
      
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ error: "Servidor não configurado com SUPABASE_SERVICE_ROLE_KEY" });
      }

      const safeLogin = login ? login.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() : 'user';
      const userEmail = email || `${safeLogin}@focarodas.com`;

      // Create user in Supabase Auth
      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email: userEmail,
        password: password,
        email_confirm: true,
        user_metadata: { name, role, login }
      });

      if (authError) {
        if (authError.message.includes('already been registered')) {
            return res.status(400).json({ error: "Este login ou e-mail já está em uso por outro usuário." });
        }
        if (authError.message.includes('Unable to validate email address: invalid format')) {
            return res.status(400).json({ error: "Formato de e-mail inválido, ou login contêm formato inválido." });
        }
        if (authError.message.includes('Password should be at least 6 characters')) {
            return res.status(400).json({ error: "A senha deve ter pelo menos 6 caracteres." });
        }
        return res.status(400).json({ error: authError.message });
      }

      const userId = authData.user.id;

      // Insert into public.employees
      const { data: empData, error: empError } = await supabaseAdmin
        .from('employees')
        .insert([{
          id: userId,
          name,
          email: userEmail,
          login,
          password, // Keeping it for backward compatibility if needed, or better omit it if they requested to drop it, but let's keep the shape
          role,
          active,
          created_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (empError) {
        // Rollback created user
        await supabaseAdmin.auth.admin.deleteUser(userId);
        if (empError.message.includes("Could not find the table")) {
           return res.status(400).json({ error: "TABELAS MENCIONADAS NÃO EXISTEM NO SUPABASE. Leia o arquivo supabase-schema-v2.sql e execute-o no SQL Editor do seu Supabase para criar a base de dados." });
        }
        return res.status(400).json({ error: empError.message });
      }

      res.json({ success: true, employee: empData });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Update Employee
  app.post("/api/admin/update-employee", async (req, res) => {
    try {
      const { id, updates } = req.body;
      
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ error: "Servidor não configurado com SUPABASE_SERVICE_ROLE_KEY" });
      }

      // If updating login or password or email, we might need to update Auth
      const authUpdates: any = {};
      if (updates.password) authUpdates.password = updates.password;
      if (updates.login || updates.email) {
          const safeLogin = updates.login ? updates.login.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() : undefined;
          authUpdates.email = updates.email || (safeLogin ? `${safeLogin}@focarodas.com` : undefined);
      }

      if (Object.keys(authUpdates).length > 0) {
        const { error: authError } = await supabaseAdmin.auth.admin.updateUserById(id, authUpdates);
        if (authError) {
           return res.status(400).json({ error: "Erro ao atualizar autenticação: " + authError.message });
        }
      }

      const { data: empData, error: empError } = await supabaseAdmin
        .from('employees')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (empError) {
        return res.status(400).json({ error: empError.message });
      }

      res.json({ success: true, employee: empData });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Create Client
  app.post("/api/admin/create-client", async (req, res) => {
    try {
      const { email, password, name, login, phone, address, status, observations } = req.body;
      
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ error: "Servidor não configurado com SUPABASE_SERVICE_ROLE_KEY" });
      }

      const safeLogin = login ? login.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() : 'client';
      const userEmail = email || `${safeLogin}@focarodas.com`;

      // Create user in Supabase Auth
      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email: userEmail,
        password: password,
        email_confirm: true,
        user_metadata: { name, phone }
      });

      if (authError) {
        if (authError.message.includes('already been registered')) {
            return res.status(400).json({ error: "Este login ou e-mail já está em uso por outro usuário." });
        }
        if (authError.message.includes('Unable to validate email address: invalid format')) {
            return res.status(400).json({ error: "Formato de e-mail inválido, ou login contêm formato inválido." });
        }
        if (authError.message.includes('Password should be at least 6 characters')) {
            return res.status(400).json({ error: "A senha deve ter pelo menos 6 caracteres." });
        }
        return res.status(400).json({ error: authError.message });
      }

      const userId = authData.user.id;

      // Insert into public.clients
      const { data: clientData, error: clientError } = await supabaseAdmin
        .from('clients')
        .insert([{
          id: userId,
          name,
          email: userEmail,
          login,
          password, 
          phone,
          address,
          status,
          observations,
          created_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (clientError) {
        // Rollback
        await supabaseAdmin.auth.admin.deleteUser(userId);
        if (clientError.message.includes("Could not find the table")) {
           return res.status(400).json({ error: "TABELAS MENCIONADAS NÃO EXISTEM NO SUPABASE. Leia o arquivo supabase-schema-v2.sql e execute-o no SQL Editor." });
        }
        return res.status(400).json({ error: clientError.message });
      }

      res.json({ success: true, client: clientData });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // Update Client
  app.post("/api/admin/update-client", async (req, res) => {
    try {
      const { id, updates } = req.body;
      
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ error: "Servidor não configurado com SUPABASE_SERVICE_ROLE_KEY" });
      }

      const authUpdates: any = {};
      if (updates.password) authUpdates.password = updates.password;
      if (updates.login || updates.email) {
          const safeLogin = updates.login ? updates.login.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() : undefined;
          authUpdates.email = updates.email || (safeLogin ? `${safeLogin}@focarodas.com` : undefined);
      }

      if (Object.keys(authUpdates).length > 0) {
        const { error: authError } = await supabaseAdmin.auth.admin.updateUserById(id, authUpdates);
        if (authError) {
           return res.status(400).json({ error: "Erro ao atualizar autenticação: " + authError.message });
        }
      }

      const { data: clientData, error: clientError } = await supabaseAdmin
        .from('clients')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (clientError) {
        return res.status(400).json({ error: clientError.message });
      }

      res.json({ success: true, client: clientData });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // === VITE MIDDLEWARE ===
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
