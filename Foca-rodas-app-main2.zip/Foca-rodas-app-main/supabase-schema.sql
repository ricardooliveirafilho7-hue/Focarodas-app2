-- Rode este script no Editor SQL do seu projeto Supabase

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE clients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome TEXT NOT NULL,
  telefone TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE cars (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  marca TEXT NOT NULL,
  modelo TEXT NOT NULL,
  ano INTEGER,
  cor TEXT,
  placa TEXT,
  quilometragem INTEGER,
  foto_url TEXT,
  observacoes TEXT,
  status_geral TEXT,
  nota_geral INTEGER,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE car_status (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  car_id UUID UNIQUE REFERENCES cars(id) ON DELETE CASCADE,
  pneus_status TEXT,
  pneus_observacao TEXT,
  alinhamento_status TEXT,
  alinhamento_observacao TEXT,
  balanceamento_status TEXT,
  balanceamento_observacao TEXT,
  freios_status TEXT,
  freios_observacao TEXT,
  suspensao_status TEXT,
  suspensao_observacao TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE car_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  car_id UUID REFERENCES cars(id) ON DELETE CASCADE,
  tipo_servico TEXT,
  descricao TEXT,
  quilometragem INTEGER,
  data_servico DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE device_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  car_id UUID REFERENCES cars(id) ON DELETE CASCADE,
  fcm_token TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Policies if needed (Allow public access for this simple test app)
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE cars ENABLE ROW LEVEL SECURITY;
ALTER TABLE car_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE car_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE device_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public all access on clients" ON clients FOR ALL USING (true);
CREATE POLICY "Allow public all access on cars" ON cars FOR ALL USING (true);
CREATE POLICY "Allow public all access on car_status" ON car_status FOR ALL USING (true);
CREATE POLICY "Allow public all access on car_history" ON car_history FOR ALL USING (true);
CREATE POLICY "Allow public all access on device_tokens" ON device_tokens FOR ALL USING (true);
